REM Program:	custom_cellperf.sql
REM 		Oracle Exadata CellPerf PlugIn
REM Version:	1.0.2
REM Author:	Bartolomeo Bogliolo mail@meo.bogliolo.name
REM             https://meoshome.it.eu.org/
REM		
REM Date:    	15-AUG-20 mail@meo.bogliolo.name
REM		First version strongly based on Oracle Support CELLPERFDIAG.SQL

set echo off
set feedback off
column timecol new_value timestamp
set trim on
set trims on
set lines 160
set long 10000
set verify off
alter session set optimizer_features_enable = '10.2.0.4';
column avg_wait_time format 99999999999.9
column cell_name format a30 wra
column cell_path format a30 wra
column cellhash format 999999999
column diskhash format 999999999
column database_id format 999999999
column disk_name format a30 wra
column event format a40 wra
column inst_id format 999
column minute format a12 tru
column sample_time format a25 tru
column total_wait_time format 99999999999999.9


set heading off
select '<P><a id="custO"></a><a id="cellperf"></a><h2>Oracle Exadata CellPerf</h2>' h from dual;
SELECT '<h3>Cell Performance Parameters</h3><pre>' from dual;  
set heading on

column name format a40 wra
column value format a40 wra
select inst_id, name, value from gv$parameter
where (name like 'cell%' or name like '_kcfis%' or name like '%fplib%')
and value is not null
order by 1, 2, 3;

set heading off
SELECT '</pre><h3>TOP 20 CURRENT CELL WAITS</h3><pre>' from dual;  
set heading on
select * from (
select c.cell_path, sw.inst_id, sw.event, sw.p1 cellhash, sw.p2 diskhash, sw.p3 bytes, sw.state, sw.seconds_in_wait
from v$cell c, gv$session_wait sw
where sw.p1text = 'cellhash#' and c.cell_hashval = sw.p1
order by 8 desc)
where rownum < 21;

set heading off
SELECT '</pre><h3>ASH CELL PERFORMANCE SUMMARY</h3><pre>' from dual;  
set heading on
select c.cell_path, sum(a.time_waited) TOTAL_WAIT_TIME, avg(a.time_waited) AVG_WAIT_TIME
from v$cell c, gv$active_session_history a
where a.p1text = 'cellhash#' and c.cell_hashval = a.p1
group by c.cell_path
order by 3 desc, 2 desc;

set heading off
SELECT '</pre><h3>20 WORST CELL PERFORMANCE MINUTES IN ASH</h3><pre>' from dual;  
set heading on
select * from (
select to_char(a.sample_time,'Mondd_hh24mi') minute, c.cell_path,
sum(a.time_waited) TOTAL_WAIT_TIME, avg(a.time_waited) AVG_WAIT_TIME
from v$cell c, gv$active_session_history a
where a.p1text = 'cellhash#' and c.cell_hashval = a.p1
group by to_char(sample_time,'Mondd_hh24mi'), c.cell_path
order by 4 desc, 3 desc)
where rownum < 21;

set heading off
SELECT '</pre><h3>20 LONGEST CELL WAITS IN ASH ORDERED BY WAIT TIME</h3><pre>' from dual;  
set heading on 
select * from (
select a.sample_time, c.cell_path, a.inst_id, a.event, a.p1 cellhash, a.p2 diskhash, a.p3 bytes, a.time_waited
from v$cell c, gv$active_session_history a
where a.p1text = 'cellhash#' and c.cell_hashval = a.p1
order by time_waited desc)
where rownum < 21;

set heading off
SELECT '</pre><h3>50 LONGEST CELL WAITS IN ASH ORDERED BY SAMPLE TIME</h3><pre>' from dual;  
set heading on
select * from (
select * from (
select a.sample_time, c.cell_path, a.inst_id, a.event, a.p1 cellhash, a.p2 diskhash, a.p3 bytes, a.time_waited
from v$cell c, gv$active_session_history a
where a.p1text = 'cellhash#' and c.cell_hashval = a.p1
order by time_waited desc)
where rownum < 51)
order by 1;

set heading off
SELECT '</pre><h3>ASH HISTORY CELL PERFORMANCE SUMMARY</h3><pre>' from dual;  
set heading on
select c.cell_path, sum(a.time_waited) TOTAL_WAIT_TIME, avg(a.time_waited) AVG_WAIT_TIME
from v$cell c, DBA_HIST_ACTIVE_SESS_HISTORY a
where a.p1text = 'cellhash#' and c.cell_hashval = a.p1
group by c.cell_path
order by 3 desc, 2 desc;

set heading off
SELECT '</pre><h3>20 WORST CELL PERFORMANCE MINUTES IN ASH HISTORY</h3><pre>' from dual;  
set heading on
select * from (
select to_char(a.sample_time,'Mondd_hh24mi') minute, c.cell_path,
sum(a.time_waited) TOTAL_WAIT_TIME, avg(a.time_waited) AVG_WAIT_TIME
from v$cell c, DBA_HIST_ACTIVE_SESS_HISTORY a
where a.p1text = 'cellhash#' and c.cell_hashval = a.p1
group by to_char(sample_time,'Mondd_hh24mi'), c.cell_path
order by 4 desc, 3 desc)
where rownum < 21;

set heading off
SELECT '</pre><h3>20 LONGEST CELL WAITS IN ASH HISTORY ORDERED BY WAIT TIME</h3><pre>' from dual;  
set heading on 
select * from (
select a.sample_time, c.cell_path, a.instance_number inst_id, a.event, a.p1 cellhash, a.p2 diskhash, a.p3 bytes, a.time_waited
from v$cell c, DBA_HIST_ACTIVE_SESS_HISTORY a
where a.p1text = 'cellhash#' and c.cell_hashval = a.p1
order by time_waited desc)
where rownum < 21;

set heading off
SELECT '</pre><h3>20 LONGEST CELL WAITS IN ASH HISTORY ORDERED BY SAMPLE TIME</h3><pre>' from dual;  
set heading on 
select * from (
select * from (
select a.sample_time, c.cell_path, a.instance_number inst_id, a.event, a.p1 cellhash, a.p2 diskhash, a.p3 bytes, a.time_waited
from v$cell c, DBA_HIST_ACTIVE_SESS_HISTORY a
where a.p1text = 'cellhash#' and c.cell_hashval = a.p1
order by time_waited desc)
where rownum < 21)
order by 1;

set heading off
SELECT '</pre><h3>AWR CELL DISK UTILIZATION</h3><pre>' from dual;  
set heading on
select * from (select * from (
select distinct dhs.snap_id, to_char(dhs.begin_interval_time,'Mondd_hh24mi') BEGIN,
to_char(dhs.end_interval_time,'Mondd_hh24mi') END,
cd.cell_name, cd.disk_name, DISK_UTILIZATION_SUM, IO_REQUESTS_SUM, IO_MB_SUM
from dba_hist_snapshot dhs, DBA_HIST_CELL_DISK_SUMMARY cds, v$cell_disk cd
where (cds.cell_hash = cd.cell_hash and cds.disk_id = cd.disk_id)
and dhs.snap_id = cds.snap_id and to_char(dhs.begin_interval_time,'Mondd_hh24') in
(select hour from (
select to_char(a.sample_time,'Mondd_hh24') hour, avg(a.time_waited) AVG_WAIT_TIME
from DBA_HIST_ACTIVE_SESS_HISTORY a
where event like 'cell%' or event like 'db file%' or event like 'log file%' or event like 'control file%'
group by to_char(a.sample_time,'Mondd_hh24')
order by 2 desc)
where rownum < 6)
order by DISK_UTILIZATION_SUM desc, IO_REQUESTS_SUM desc)
where rownum < 101)
order by 1,2,3,4,5;

SELECT ksqdngunid DB_ID_FOR_CURRENT_DB FROM X$KSQDN;

set heading off
SELECT '</pre><h3> CELL THREAD HISTORY</h3><pre>' from dual;  
set heading on
select * from (
select count(*), sql_id, cell_name, job_type, database_id, instance_id
from v$cell_thread_history
where wait_state not in ('waiting_for_SKGXP_receive','waiting_for_connect','looking_for_job')
group by sql_id, cell_name, job_type, database_id, instance_id
order by 1 desc, 2, 3)
where rownum < 51;

set heading off
SELECT '</pre><h3>CELL CONFIG</h3><pre>' from dual;  
set heading on
select cellname, XMLTYPE.createXML(confval) confval
from v$cell_config
where conftype='CELL';

set heading off
SELECT '</pre><h3>IORM CONFIG</h3><pre>' from dual;  
set heading on
select cellname, XMLTYPE.createXML(confval) confval
from v$cell_config
where conftype='IORM';

set heading off
select '</pre><p><a href="#top">Top</a> <a href="#custMenu">Plugins</a><hr><p>' from dual;
