REM Program:	custom_spatial.sql
REM 		Custom Oracle Spatial Plug-in
REM Version:	1.0.0
REM Author:	Bartolomeo Bogliolo mail@meo.bogliolo.name
REM		
REM Date:    	15-AUG-24 mail@meo.bogliolo.name
REM		
REM		This plugin is intended for Oracle Spatial configuration

set colsep ' '
set linesize 132
set heading off
set feedback off
set timing off
column owner format a20 trunc

set heading off
select '<P><a id="custO"></a><a id="spatial"></a><h2>Spatial</h2><pre>' h from dual;
set heading on

select owner, count(*) as Spatial_tables
 from all_sdo_geom_metadata
 group by owner
union all
select 'TOTAL', count(*)
 from all_sdo_geom_metadata;

set heading off
select '</pre><p><a href="#top">Top</a> <a href="#custMenu">Plugins</a><hr><p>' from dual;
