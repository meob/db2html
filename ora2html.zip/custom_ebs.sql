REM Program:	custom_ebs.sql
REM 		Oracle EBS PlugIn
REM Version:	1.0.0
REM Author:	Bartolomeo Bogliolo mail@meo.bogliolo.name
REM             http://www.xenialab.it/meo/web/index5.htm
REM		
REM Date:    	15-AUG-12 mail@meo.bogliolo.name

set linesize 132
set heading off

select '<P><a id="cust0"></a><a id="ebs"></a><h2>Oracle EBS Statistics</h2>' h from dual;
select '<hr><P><a id="status"></A>' "Status" from dual;
select '<P><table border="2"><tr><td><b>Summary</b></td></tr>'
 from dual;
select '<tr><td><b>Item</b>',
 '<td><b>Value</b>'
from dual;

select '<tr><td>'||' Instance: ', '<! 10>', '<td>'||applications_system_name 
  FROM APPLSYS.fnd_product_groups;
select '<tr><td>'||' eBS Release :', '<! 12>', '<td>'||release_name 
  FROM APPLSYS.fnd_product_groups;
select '<tr><td>'||' Languages :', '<! 13>', '<td>'
  from dual;
select distinct language
  from APPLSYS.FND_APPLICATION_TL;

select '<tr><td>'||' DB Version :', '<! 13>',
 '<td>'||substr(banner,instr(banner, '.',1,1)-2,11)
from sys.v_$version
where banner like 'Oracle%'
union
select '<tr><td>'||' URL:', '<! 14>',
 '<td>'||home_url
from ICX.ICX_PARAMETERS
union
select '<tr><td>'||' Application Servers IPs:', '<! 16>',
 '<td>'||server_address
from APPLSYS.FND_APPLICATION_SERVERS
union
select '<tr><td>'||' Defined Users :', '<! 30>',
 '<td align="right">'||to_char(count(*),'999,999,999,999')
from APPLSYS.FND_USER
union
select '<tr><td>'||' Active Users (last year):', '<! 32>',
 '<td align="right">'||to_char(count(*),'999,999,999,999')
from APPLSYS.FND_USER
where last_logon_date > sysdate-366
union
select '<tr><td>'||' Connected Users :', '<! 34>',
 '<td align="right">'||to_char(count(*),'999,999,999,999')
from apps.icx_sessions
where last_connect > sysdate-1/96
order by 2;

select '</table><p><hr>' from dual;

select '<P><a id="rel"></A>' from dual;
select '<P><table border="2"><tr><td><b>Release</b><td><b>Type</b><td><b>System</b></tr>' from dual;
SELECT '<tr><td>'||release_name Release, '<td>'||product_group_type GroupType, '<td>'||applications_system_name
FROM APPLSYS.fnd_product_groups;  
select '</table><p>' from dual;

select '<P><a id="langs"></A>' from dual;
select '<P><table border="2"><tr><td><b>Features count for Language' from dual;
select '<tr><td><b>Language</b><td><b>Applications Count</b></tr>' from dual;
select '<tr><td>'|| language, '<td>'||count(*)
from APPLSYS.FND_APPLICATION_TL
group by language;
select '</table><p>' from dual;

select '<P><a id="appls"></A>' from dual;
select '<P><table border="2"><tr><td><b>Applications List</b></td></tr><tr><td>' from dual;
select application_short_name
from APPLSYS.FND_APPLICATION
order by 1;
select '</table><p><hr>' from dual;

select '<P><a id="servers"></A>' from dual;
select '<P><table border="2"><tr><td><b>Application Server Address</b><td><b>Description</b></tr>' from dual;
select '<tr><td>'|| server_address, '<td>'||description
from APPLSYS.FND_APPLICATION_SERVERS;
select '</table><p>' from dual;

select '<P><a id="nodes"></A>' from dual;
select '<P><table border="2"><tr><td><b>Node</b><td><b>IP</b>',
 '<td>Concurrent Process',
 '<td>Forms',
 '<td>Web',
 '<td>Admin',
 '<td>DB'
from dual;
select '<tr><td>'|| node_name,
 '<td>'||server_address,
 '<td>'||support_cp,
 '<td>'||support_forms,
 '<td>'||support_web,
 '<td>'||support_admin,
 '<td>NA'
from APPLSYS.FND_NODES
where node_name <> 'AUTHENTICATION';
select '</table><p>' from dual;

select '<P><a id="url"></A>' from dual;
select '<P><table border="2"><tr><td><b>URL</b></td></tr>' from dual;
select '<tr><td>'|| home_url
from ICX.ICX_PARAMETERS;
select '</table><p><hr>' from dual;

select '<P><a id="cproc"></A>' from dual;
select '<P><table border="2"><tr><td><b>Concurrent Processor Name</b>',
 '<td><b>Description</b></tr>' from dual;
select '<tr><td>'|| CONCURRENT_PROCESSOR_NAME, '<td>'||description
from APPLSYS.FND_CONCURRENT_PROCESSORS
order by 1;
select '</table><p>' from dual;

select '<P><a id="cprog"></A>' from dual;
select '<P><table border="2"><tr><td><b>Concurrent Programs</b></td></tr>' from dual;
select '<tr><td align=right>'|| count(*)
from APPLSYS.FND_CONCURRENT_PROGRAMS;
select '</table><p><hr>' from dual;

select '<P><a id="users"></A>' from dual;
select '<P><table border="2"><tr><td><b>EBS Active Users</b>',
 '<td><b>Description</b><td><b>Last Logon</b></tr>' from dual;
select '<tr><td>'|| user_name, '<td>'||description, '<td>'||last_logon_date
from APPLSYS.FND_USER
where last_logon_date > sysdate - 366
order by last_logon_date desc;
select '</table><p><hr>' from dual;

select '<P><a id="patches"></A>' from dual;
select '<P><table border="2"><tr><td><b>Patches</b></td></tr>' from dual;
select '<tr><td><b>Name</b><td><b>Type</b><td><b>Date</b></tr>' from dual;
select '<tr><td>'||patch_name, '<td>'||patch_type, '<td>'||to_char(max(creation_date),'YYYY-MM-DD HH24:MI:SS')
from APPLSYS.AD_APPLIED_PATCHES
group by  patch_name, patch_type
order by  max(creation_date) desc, patch_type, patch_name desc;
select '</table><p>' from dual;

select '<P><a id="bug"></A>' from dual;
select '<P><table border="2"><tr><td><b>Bugs</b></td></tr>' from dual;
select '<tr><td><b>Release</b><td><b>Application</b><td><b>Count</b></tr>' from dual;
select '<tr><td>'||aru_release_name, '<td>'||application_short_name, '<td>'|| count(*)
from applsys.ad_bugs
group by aru_release_name, application_short_name
order by aru_release_name, application_short_name;
select '</table><p>' from dual;

select '<p><a href="#top">Top</a> <a href="#custMenu">Plugins</a><hr><p>' from dual;
