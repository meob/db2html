# Program:	ch2html.sh
# 		ClickHouse DBA Database report in HTML
#
# Version:      1.0.2
# Author:       Bartolomeo Bogliolo mail@meo.bogliolo.name
# Date:         1-APR-2019
# License:      Apache 2.0
#
# Note:
# Init:       1-APR-2019 meo@bogliolo.name
#               Initial version based on MySQL my2html
# 1.0.1       1-MAY-2019 meo@bogliolo.name
#               Small bugs fixing
# 1.0.2       1-AUG-2019 meo@bogliolo.name
#               Small bugs fixing

USR=default
# Careful with security, Eugene!!
PSS=
HST=127.0.0.1
HSTN=`hostname`
PRT=8123

echo '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8" /><link rel="stylesheet" href="ux3.css" /> <title>' $HSTN : $PRT \
   ' - ch2html ClickHouse Statistics</title></head><body>' > $HSTN.$PRT.htm

# clickhouse-client --user=$USR --password=$PSS -mn --ignore-error >> $HSTN.$PRT.htm <<EOF 2>/dev/null
clickhouse-client -mn --ignore-error >> $HSTN.$PRT.htm <<EOF 2>/dev/null

use system;
select '<h1>ClickHouse Database</h1>';

select '<P><A NAME="top"></A>' ;
select '<p>Table of contents:' ;
select '<table><tr><td><ul>' ;
select '<li><A HREF="#status">Summary Status</A></li>' ;
select '<li><A HREF="#ver">Versions</A></li>' ;
select '<li><A HREF="#obj">Schema/Object Matrix</A></li>' ;
select '<li><A HREF="#tbs">Space Usage</A></li>' ;
select '<li><A HREF="#part">Partitioning</A></li>' ;
select '<li><A HREF="#comp">Compression</A></li>' ;
select '<li><A HREF="#tune">Tuning Parameters</A> </li>' ;
select '<li><A HREF="#eng">Engines</A></li>' ;
select '</ul><td><ul>' ;
select '<li><A HREF="#prc">Threads</A></li>' ;
select '<li><A HREF="#run">Running SQL</A> </li>' ;
select '<li><A HREF="#stat">Performance Statistics</A></li>' ;
select '<li><A HREF="#big">Biggest Objects</A></li>' ;
select '<li><A HREF="#hostc">Host Statistics</A></li>' ;
select '<li><A HREF="#repl">Replication</A></li>' ;
select '<li><A HREF="#par">Configuration Parameters</A></li>' ;
select '<li><A HREF="#gstat">Global Status</A></li>' ;
select '<li><A HREF="#os">Operating System info</A></li>' ;
select '</ul></table><p><hr>' ;
 
select '<P>Statistics generated on: ', now();
select 'using: <I><b>ch2html.sh</b> v.1.0.2 (2019-08-01)';
select '<br>Software by ';
select '<A HREF="http://www.xenialab.it/meo/web/index5.htm#dwn">Meo</A></I><p><HR>';

select '<P><A NAME="status"></A>';
select '<P><table border="2"><tr><td><b>Summary</b></td></tr>';
select '<tr><td><b>Item</b>', '<td><b>Value</b>';

select '<tr><td>Version :', '<td>', version();
select '<tr><td>Created :', '<td>', min(metadata_modification_time)
  from system.tables
 where metadata_modification_time<>'0000-00-00 00:00:00';
select '<tr><td>Started :', '<td>', now()-uptime();
select '<tr><td>DB Size :', '<td align=right>',
       formatReadableSize(sum(bytes_on_disk))
  from system.parts;
select '<tr><td>Max Memory (Configured/Used) :', '<td align="right">',
       formatReadableSize(toInt32(value)), ' / '
  from system.settings
 where name='max_memory_usage';
select formatReadableSize(max(memory_usage))
  from system.query_log
 where type=2;
select '<tr><td>Logged Users :', '<td align=right>', count(distinct initial_user)
  from system.query_log;;
select '<tr><td>Defined Schemata :', '<td align="right">', count()
  from system.databases;
select '<tr><td>Defined Tables :', '<td align=right>',count()
  from system.tables;
select '<tr><td>Sessions (TCP/HTTP/Replica):', '<td align=right>', value, ' / '
  from system.metrics
 where metric='TCPConnection';
select value, ' / '
  from system.metrics
 where metric='HTTPConnection';
select value
  from system.metrics
 where metric='InterserverConnection';
select '<tr><td>Sessions (active) :', '<td align="right">', count()
  from system.processes;
select '<tr><td>Query (#/hour) :', '<td align=right>', round(count(*)/24,5)
  from system.query_log
 where event_time > now() - interval 1 day;
select '<tr><td>Merges/Day (Unc. bytes) :', '<td align=right>', formatReadableSize(value/uptime()*60*60*24)
  from system.events
 where event = 'MergedUncompressedBytes';
select '<tr><td>Hostname :', '<td>', hostName();
select '</table><p><hr>' ;

select '<P><A NAME="ver"></A>';
select '<P><table border="2"><tr><td><b>Version check</b></td></tr>' ;
select '<tr><td><b>Version</b>',
 '<td><b> Current year release </b>',
 '<td><b> Recent releases </b>',
 '<td><b> Notes</b>';
select '<tr><td>', version();
select '<td>', if(value>19000000,'Yes','No')
  from system.metrics
 where metric='VersionInteger';
select '<td>', if(value>=19010001 ,'Yes','No')
  from system.metrics
 where metric='VersionInteger';
select '<td>Latest Stable Release: 19.13.2.19';
select '</table><p>' ;
select '<!-- 19.11.8, 18.14.15, 1.1.54385, 1.1.54343, 1.1.54327, 1.1.54292 -->';
 
select '<P><A NAME="obj"></A>' ;
select '<P><table border="2"><tr><td><b>Schema/Object Matrix</b></td></tr>' ;
select '<tr><td><b>Database</b>',
 '<td><b> Tables</b>',
 '<td><b> Columns</b>',
 '<td><b> Partitions</b>',
 '<td><b> Parts</b>',
 '<td><b> Replicas</b>',
 '<td><b> All</b>' ;
select '<tr><td>', sk,
	'<td align=right>', sum(if(otype='T',1,0)),
	'<td align=right>', sum(if(otype='C',1,0)),
	'<td align=right>', sum(if(otype='A',1,0)),
	'<td align=right>', sum(if(otype='P',1,0)),
	'<td align=right>', sum(if(otype='R',1,0)),
	'<td align=right>', count(*)
from ( select 'T' otype, database sk, name
  from system.tables
  union all
 select 'C' otype, database sk, concat(table,'.',name) name
  from system.columns
  union all
 select distinct 'A' otype, database sk, concat(table,'.',partition) name
  from system.parts
  union all
 select 'P' otype, database sk, concat(table,'.',name) name
  from system.parts
  union all
 select 'R' otype, database sk, table name
  from system.replicas
     ) a
group by sk;
select '</table><p>' ;

select '<P><A NAME="tbs"></A>' ;
select '<P><table border="2"><tr><td><b>Space Usage</b></td></tr>' ;
select '<tr><td><b>Database',
 '<td><b>Row#</b>',
 '<td><b>Size</b>',
 '<td><b>Data compressed</b>',
 '<td><b>Data uncompressed</b>';
SELECT '<tr><td>',database, '<td align=right>', sum(rows),
       '<td align=right>', formatReadableSize(sum(bytes_on_disk)),
       '<td align=right>', formatReadableSize(sum(data_compressed_bytes)), 
       '<td align=right>', formatReadableSize(sum(data_uncompressed_bytes))
  FROM system.parts
 GROUP BY database
 ORDER BY database;
select '</table><p>' ;

select '<P><table border="2"><tr><td><b>Space Usage Details</b></td></tr>' ;
select '<tr><td><b>Database',
 '<td><b>Table</b>',
 '<td><b>Row#</b>',
 '<td><b>Days</b>',
 '<td><b>Size</b>',
 '<td><b>Size (active)</b>',
 '<td><b>Data compressed</b>',
 '<td><b>Data uncompressed</b>';
SELECT '<tr><td>',database, '<td>', table,'<td align=right>', sum(rows),
       '<td align=right>', toUInt32((max(max_time) - min(min_time)) / 86400),
       '<td align=right>', formatReadableSize(sum(bytes_on_disk)),
       '<td align=right>', formatReadableSize(sum(if(active,bytes_on_disk,0))),
       '<td align=right>', formatReadableSize(sum(data_compressed_bytes)), 
       '<td align=right>', formatReadableSize(sum(data_uncompressed_bytes))
  FROM system.parts
 GROUP BY database, table
 ORDER BY database, table;
select '</table><p><hr>' ;

select '<P><A NAME="part"></A>' ;
select '<P><table border="2"><tr><td><b>Tables and Partitions</b></td></tr>';
select '<tr><td><b>Database</b>',
 '<td><b>Table</b>',
 '<td><b># Partitions</b>',
 '<td><b>Min Partition</b>',
 '<td><b>Max Partition</b>',
 '<td><b># Parts</b>',
 '<td><b>Min Part</b>',
 '<td><b>Max Part</b>',
 '<td><b># Active</b>',
 '<td><b>Size</b>';
SELECT '<tr><td>',database, '<td>',table,
       '<td align="right">',count(distinct partition), '<td align="right">',min(partition), '<td align="right">',max(partition),
       '<td align="right">',count(distinct name), '<td align="right">',min(name), '<td align="right">',max(name),
       '<td align="right">',sum(active), '<td align="right">',sum(bytes_on_disk)
  FROM system.parts
 WHERE database<>'system'
 GROUP BY database, table
 ORDER BY database, table;
select '</table><p>' ;

select '<P><table border="2"><tr><td><b>Partitions and Parts</b></td></tr>';
select '<tr><td><b>Database</b>',
 '<td><b>Table</b>',
 '<td><b>Partition</b>',
 '<td><b>Part</b>',
 '<td><b>Active</b>',
 '<td><b>Size</b>';
SELECT '<tr><td>',database, '<td>',table, '<td>',partition, '<td>',name,
       '<td>',active, '<td align=right>',bytes_on_disk
  FROM system.parts
 WHERE database<>'system'
 ORDER BY database, table, partition, name
 LIMIT 200;
SELECT '<tr><td>...';
select '</table><p><hr>' ;

select '<P><A NAME="comp"></A>' ;
select '<P><table border="2"><tr><td><b>Compression</b></td></tr>';
select '<tr><td><b>Database</b>',
 '<td><b>Table</b>',
 '<td><b>Column</b>',
 '<td><b>Type</b>',
 '<td><b> Size compressed</b>',
 '<td><b>Size uncompressed</b>',
 '<td><b>Gain %</b>';
SELECT '<tr><td>',database, '<td>',table, '<td>',column, '<td>',any(type),
       '<td align=right>',sum(column_data_compressed_bytes) compressed,
       '<td align=right>',sum(column_data_uncompressed_bytes) uncompressed,
       '<td align=right>',round( (sum(column_data_uncompressed_bytes)-sum(column_data_compressed_bytes))*100/sum(column_data_uncompressed_bytes), 2)
  FROM system.parts_columns
 WHERE active
   AND database<>'system'
 GROUP BY database, table, column
 HAVING sum(column_data_uncompressed_bytes)>0
 ORDER BY database, table, column
 LIMIT 100;
SELECT '<tr><td>...';
select '</table><p><hr>' ;

select '<P><A NAME="tune"></A>' ;
select '<P><table border="2"><tr><td><b>Tuning Parameters</b></td></tr>';
select '<tr><td><b>Parameter</b>', '<td><b>Value</b>';
select '<tr><td>',name, '<td>',value
  from system.settings
 WHERE changed != 0
    OR name in ('max_memory_usage', 'max_memory_usage_for_all_queries', 'max_memory_usage_for_user',
         'max_bytes_before_external_group_by', 'max_bytes_before_external_sort',
         'max_bytes_before_remerge_sort')
 order by name;
select '</table><p>' ;

select '<P><A NAME="sga"></A>' ;
select '<P><table border="2"><tr><td><b>Max Memory Usage</b>';
select '<tr><td><b>User</b>','<td><b>Host</b>',
       '<td><b>Client</b>','<td><b>Start</b>','<td><b>Duration</b>','<td><b>Memory</b>','<td><b>Type</b>',
       '<td><b>Query</b>';
SELECT '<tr><td>',user, '<td>',client_hostname AS host, '<td>',client_name AS client,
       '<td>',query_start_time AS started, '<td>',query_duration_ms/1000 AS sec,
       '<td align=right>', formatReadableSize(memory_usage) AS MEM, '<td>',type,
       '<td>', replace(replace(query,'<','-'), '>','-') query
  FROM system.query_log
 WHERE memory_usage<>0
 ORDER BY type, memory_usage DESC
 LIMIT 5 BY type;
select '</table><p><hr>';

select '<P><A NAME="eng"></A>' ;
select '<P><table border="2"><tr><td><b>Engines usage</b></td></tr>';
select '<tr><td><b>Engine</b>', '<td><b>Table#</b>';
SELECT '<tr><td>',engine, '<td align=right>', count()
  from system.tables
 where database<>'system'
 group by engine
 order by 2 desc;
select '</table><p><hr>' ;

select '<P><table border="2"><tr><td><b>Active Merges</b></td></tr>';
select '<tr><td><b>Database</b>',
 '<td><b>Table</b>',
 '<td><b>Part</b>',
 '<td><b>Progress</b>',
 '<td><b> Elapsed </b>',
 '<td><b>Parts#</b>';
SELECT '<tr><td>',database, '<td>', table,'<td>',result_part_name,
       '<td align=right>', progress,
       '<td>', elapsed, 
       '<td align=right>', num_parts
  FROM system.merges;
select '</table><p>' ;

select '<P><table border="2"><tr><td><b>Mutations</b></td></tr>';
select '<tr><td><b>Database</b>',
 '<td><b>Table</b>',
 '<td><b>Mutation ID</b>',
 '<td><b>Command</b>',
 '<td><b>Time</b>',
 '<td><b>Done</b>',
 '<td><b>Parts to do</b>',
 '<td><b>Fail Reason</b>';
SELECT '<tr><td>',database, '<td>', table,'<td>',mutation_id,
       '<td>', command, '<td>', create_time,
       '<td>', is_done, 
       '<td align=right>', parts_to_do,
       '<td>', latest_fail_reason
  FROM system.mutations
 ORDER BY is_done, create_time desc;
select '</table><p><hr>' ;

select '<P><A NAME="prc"></A>' ;
select '<P><table border="2"><tr><td><b>Sessions</b></td></tr>' ;
select '<tr><td><b>Type</b> <td><b>Count</b>';
select '<tr><td>TCP (clickhouse-client and native connections)', '<td>', value
  from system.metrics
 where metric='TCPConnection';
select '<tr><td>HTTP (drivers and programs)', '<td>', value
  from system.metrics
 where metric='HTTPConnection';
select '<tr><td>Interserver (replica and cluster)', '<td>', value
  from system.metrics
 where metric='InterserverConnection';
select '</table><p>' ;

select '<P><A NAME="run"></A>' ;
select '<P><table border="2"><tr><td><b>Active Sessions</b></td></tr>' ;
select '<tr><td><b>Id</b><td><b>User</b><td><b>Host</b>';
select '<td><b>Elapsed</b><td><b>Command</b>';
select '<tr><td>',query_id,
	'<td>', user,
	'<td>', address,
	'<td>', elapsed,
	'<td>', replace(replace(query,'<','-'), '>','-') queryHideMe
  from system.processes
 where query not like ('% queryHideMe%')
 order by query_id;
select '</table><p>' ;

select '<P><A NAME="stat"></A>' ;
select '<a id="sqls"></a><P><table border="2"><tr><td><b>Latest SQL Statements</b></td>' ;
select '<tr><td><b>User</b>','<td><b>Host</b>',
       '<td><b>Client</b>','<td><b>Start</b>','<td><b>Duration</b>','<td><b>Mem MB</b>',
       '<td><b>Rows</b>','<td><b>Result MB</b>','<td><b>Rows Examined</b>',
       '<td><b>Read MB</b>','<td><b>Written rows</b>',
       '<td><b>Written MB</b>','<td><b>Query</b>';
SELECT '<tr><td>',user, '<td>',client_hostname AS host, '<td>',client_name AS client,
       '<td>',query_start_time AS started, '<td align=right>',query_duration_ms/1000 AS sec,
       '<td align=right>',round(memory_usage/1048576) AS MEM_MB, '<td align=right>',result_rows AS RES_CNT,
       '<td align=right>',toDecimal64(result_bytes/1048576, 6) AS RES_MB, '<td align=right>',read_rows AS R_CNT,
       '<td align=right>',round(read_bytes/1048576) AS R_MB, '<td align=right>',written_rows AS W_CNT,
       '<td align=right>',round(written_bytes/1048576) AS W_MB,
       '<td>', replace(replace(query,'<','-'), '>','-') query
  FROM system.query_log
 WHERE user <> 'my2'
 ORDER BY query_start_time DESC
 LIMIT 10;
select '</table><p>';

select '<p><a id="sqlslow"></a><p><table border="2"><tr><td><b>Slowest Statements</b>' ;
select '<tr><td><b>User</b>','<td><b>Host</b>',
       '<td><b>Client</b>','<td><b>Start</b>','<td><b>Duration</b>','<td><b>Mem MB</b>',
       '<td><b>Rows</b>','<td><b>Result MB</b>','<td><b>Rows Examined</b>',
       '<td><b>Read MB</b>','<td><b>Written rows</b>',
       '<td><b>Written MB</b>','<td><b>Query</b>';
SELECT '<tr><td>',user, '<td>',client_hostname AS host, '<td>',client_name AS client,
       '<td>',query_start_time AS started, '<td align=right>',query_duration_ms/1000 AS sec,
       '<td align=right>',round(memory_usage/1048576) AS MEM_MB, '<td align=right>',result_rows AS RES_CNT,
       '<td align=right>',toDecimal64(result_bytes/1048576, 6) AS RES_MB, '<td align=right>',read_rows AS R_CNT,
       '<td align=right>',round(read_bytes/1048576) AS R_MB, '<td align=right>',written_rows AS W_CNT,
       '<td align=right>',round(written_bytes/1048576) AS W_MB,
       '<td>', replace(replace(query,'<','-'), '>','-') query
  FROM system.query_log
 ORDER BY query_duration_ms DESC
 LIMIT 20;

select '</table><p><a id="sqlslowu"></a><p><table border="2"><tr><td><b>5 Slowest SELECT (by user)</b>' ;
select '<tr><td><b>User</b>','<td><b>Host</b>',
       '<td><b>Client</b>','<td><b>Start</b>','<td><b>Duration</b>','<td><b>Mem MB</b>',
       '<td><b>Rows</b>','<td><b>Result MB</b>','<td><b>Rows Examined</b>',
       '<td><b>Read MB</b>','<td><b>Written rows</b>',
       '<td><b>Written MB</b>','<td><b>Query</b>';
select *
 from (SELECT '<tr><td>',user, '<td>',client_hostname AS host, '<td>' td2,client_name AS client,
       '<td>' td3,query_start_time AS started, '<td align=right>',query_duration_ms/1000 AS sec,
       '<td align=right>' td5,round(memory_usage/1048576) AS MEM_MB, '<td align=right>' td6,result_rows AS RES_CNT,
       '<td align=right>' td7,toDecimal64(result_bytes/1048576, 6) AS RES_MB, '<td align=right>' td8,read_rows AS R_CNT,
       '<td align=right>' td9,round(read_bytes/1048576) AS R_MB, '<td align=right>' td10,written_rows AS W_CNT,
       '<td align=right>' td11,round(written_bytes/1048576) AS W_MB,
       '<td>' td12, replace(replace(query,'<','-'), '>','-') query
  FROM system.query_log
 WHERE type=2
   AND user <> 'my2'
 ORDER BY query_duration_ms DESC
 LIMIT 5 BY user)
order by user, sec DESC;
select '</table><p><hr>';

select '<P><A NAME="big"></A>' ;
select '<P><table border="2"><tr><td><b>Biggest Objects</b></td></tr>' ;
select '<tr><td><b>Database</b>',
 '<td><b>Table</b>',
 '<td><b>Engine</b>',
 '<td><b>Rows</b>',
 '<td><b>Size</b>',
 '<td><b>Size (bytes)</b>';
SELECT '<tr><td>',database, '<td>', table, '<td>', any(engine),
       '<td align=right>', sum(rows),
       '<td align=right>', formatReadableSize(sum(bytes_on_disk)),
       '<td align=right>', sum(bytes_on_disk)
  FROM system.parts
 WHERE database<>'system'
 GROUP BY database, table
 ORDER BY sum(bytes_on_disk) desc
 LIMIT 32;
select '</table><p><hr>' ;

select '<P><A NAME="hostc"></A>' ;
select '<P><A NAME="dict"></A>' ;
select '<P><table border="2"><tr><td><b>Dictionaries</b></td></tr>' ;
select '<tr><td><pre>' ;
SELECT *
  FROM system.dictionaries;
select '</pre></table><p><hr>' ;


select '<P><A NAME="clu"></A>' ;
select '<P><table border="2"><tr><td><b>Cluster configuration</b></td></tr>' ;
select '<tr><td><b>Cluster</b>',
 '<td><b>Shard#</b>',
 '<td><b>Shard weight</b>',
 '<td><b>Replica#</b>',
 '<td><b>Hostname</b>',
 '<td><b>Address</b>',
 '<td><b>Port</b>',
 '<td><b>Local</b>',
 '<td><b>User</b>',
 '<td><b>Default database</b>';
SELECT '<tr><td>',cluster, '<td align=right>', shard_num, '<td>',shard_weight,
       '<td align=right>', replica_num,
       '<td>', host_name,
       '<td>', host_address,
       '<td>', port,
       '<td>', is_local,
       '<td>', user,
       '<td>', default_database
  FROM system.clusters;
select '</table><p>' ;

select '<P><A NAME="repl"></A>' ;
select '<P><table border="2"><tr><td><b>Replication</b></td></tr>' ;
select '<tr><td><pre>' ;
SELECT *
  FROM system.replicas
FORMAT Vertical;
select '</pre></table><p><hr>' ;


select '<P><A NAME="stor"></A>' ;
select '<P><A NAME="dtype"></A>' ;
select '<P><table border="2"><tr><td><b>Datatype Usage</b></td></tr>' ;
select '<tr><td><b>Database</b>',
 '<td><b>Data Type</b>',
 '<td><b>Count#</b>';
select '<tr><td>', database, '<td>', type,  '<td>', count()
  from system.columns
 where database<>'system'
 group by database, type
 order by database, type;
select '</table><p><hr>' ;

select '<P><A NAME="par"></A>' ;
select '<P><table border="2"><tr><td><b>ClickHouse Parameters</b></td></tr>';
select '<tr><td><b>Parameter</b>',
 '<td><b>Value</b>', '<td><b>Changed</b>' ;
select '<tr><td>',name, '<td>',value, '<td>',changed
  from system.settings
 order by changed desc, name;
select '</table><p><hr>' ;

select '<P><A NAME="gstat"></A>' ;
select '<P><table border="2"><tr><td><b>ClickHouse Metrics</b></td></tr>';
select '<tr><td><b>Statistic</b>', '<td><b>Value</b>', '<td><b>Description </b>' ;
select '<tr><td>', metric, '<td align=right>', value,  '<td>', description
  from system.metrics
 order by metric;
select '</table><p>' ;

select '<P><table border="2"><tr><td><b>ClickHouse Async. Metrics</b></td></tr>';
select '<tr><td><b>Statistic</b>', '<td><b>Value</b>' ;
select '<tr><td>', metric, '<td align=right>', value
  from system.asynchronous_metrics
 order by metric;
select '</table><p>' ;

select '<P><table border="2"><tr><td><b>ClickHouse Events</b></td></tr>';
select '<tr><td><b>Statistic</b>', '<td><b>Value</b>', '<td><b>Description </b>' ;
select '<tr><td>', event, '<td align=right>', value,  '<td>', description
  from system.events
 order by event;
select '</table><p>' ;

select '<P><table border="2"><tr><td><b>Part log</b></td></tr>';
select '<tr><td><pre>' ;
SELECT *
  FROM system.part_log
 order by event_date desc, event_time desc
 limit 100;
select '</pre></table><p>' ;

-- select '<hr><P>Statistics generated on: ', now();
EOF

{
echo '<P><A NAME="os"></A>' 
echo '<hr><h3>Operating system info</h3><pre>' 
echo '<b>Process Status</b>'
ps -efa | grep click | grep -v grep 
echo 
echo '<b>Packages</b>'
rpm -qa | grep clickhouse  2>/dev/null
echo 
echo '<b>Configuration Files</b>' 
ls -l /etc/clickhouse-server/ 
echo 
echo '<b>CPU Governor</b>' [Performance]
cat /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor | sort -u
echo
echo '<b>Memory Overcommit</b> [0 or 1]'
cat /proc/sys/vm/overcommit_memory 
echo
echo '<b>Memory Hugepages</b> [never]'
cat /sys/kernel/mm/transparent_hugepage/enabled 
echo
echo '<b>Disk Scheduler</b> [HDD:CFQ, SSD:noop]' 
ls /sys/block/*/queue/scheduler 
cat /sys/block/*/queue/scheduler 
# cat /sys/block/*/*/stripe_cache_size 
echo
echo '<b>File System Mounts</b> [ext4 with noatime,nobarrier]' 
cat /proc/mounts 
echo
df -h
echo
echo '</pre><P><A NAME="logs"></A>' 
echo '<hr><h3>ClickHouse  Logs</h3><xmp>' 
echo '*** ClickHouse Server Log ***'
tail -50 /var/log/clickhouse-server/clickhouse-server.log
echo
echo '*** Errors in  Server Log ***'
grep "<Error>" /var/log/clickhouse-server/clickhouse-server.log | tail -10
echo
echo '*** ClickHouse Error Log ***'
tail -30 /var/log/clickhouse-server/clickhouse-server.err.log
echo
echo '</xmp><hr><P>Statistics generated on: ' 
date  
echo '<p>For more info on ch2html contact' 
echo '<A HREF="mailto:mail@meo.bogliolo.name">Meo Bogliolo</A>.<p></body></html>' 
} >> $HSTN.$PRT.htm
exit 0
